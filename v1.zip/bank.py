#!/usr/bin/env python
#-*- encoding=utf-8 -*-
#该程序由队伍“C-moon”实现，包括钱非凡、贾潇风、陈恺凡，队长为钱非凡
#该程序主要实现RSA公私钥对生成算法、对用户端发送信息进行签名、存储并验证{σ,m}
#该程序遵循 https://blog.csdn.net/qmickecs/article/details/73556098 的建议
#完成时间：2019/09/21
import hashlib
import gmpy2
import random
import time
import os

#创建“数据库”
def create_db():
    os.system('touch allcheck.txt')

#欢迎界面
def welcome():
    print ' --- Welcome to C-moon Bank System! --- '
    print '|      0: Generate key-pair            |'
    print '|      1: Sign                         |'
    print '|      2: Check Double Spending        |'
    print '|      3: Exit                         |'
    print ' -------------------------------------- '

#输入为随机数种子，返回大素数
#@rs：随机数种子
def getprime(rs):
    p = gmpy2.mpz_urandomb(rs, 1024)
    while not gmpy2.is_prime(p):
        p = p + 1
    return p

#生成公私钥对并返回
def keygen():
    rs = gmpy2.random_state(int(time.time())) #随机数种子
    p = getprime(rs)  #大素数p       
    q = getprime(rs)  #大素数q
    n = p * q         #大整数n
    e = 0x10001
    H = lambda m: int(hashlib.sha256(m).hexdigest(), 16) #hash函数
    pk = [n, e, H]   #公钥对
    with open('pk.txt', 'w') as f: #pk.txt作为公开的公钥文件
        f.write(str(pk[0]) + '\n')
        f.write(str(pk[1]) + '\n')
        print '[*] Write pk successfully!'
    d = gmpy2.invert(e, (p - 1) * (q - 1)) #私钥
    sk = d
    return pk, sk

#输入公私钥对已经盲变换后的信息,返回签名
#@pk：RSA公钥
#@sk：RSA私钥
#@M：盲化后的数据
def sign(pk, sk):
    with open('M.txt', 'r') as f:
        M = int(f.read())
        print '[+] M =', M
    n = pk[0]
    d = sk
    sigma = gmpy2.powmod(M, d, n)  #签名
    print '[+] σ\' =', sigma
    with open('sigma.txt', 'w') as f:
        f.write(str(sigma))
        print '[*] Signed successfully'

#读取已存储的信息防止双花
def check_double_spending():
    #从“数据库”读取已存储的信息
    allcheck = []
    with open('allcheck.txt', 'r') as f:
        while True:
            line = f.readline()
            if line == '':
                break
            allcheck.append(line.replace('\n', ''))

    with open('check.txt', 'r') as f: #check.txt为存储验证方发送的{σ,m}数据的文件
        check = f.readline()[:-1]
    #如果验证方发送的信息已经存在与allcheck列表内，说明用户双花，否则将该数据存储于allcheck文件内
    if check in allcheck:
        print '[-] Double Spending!'
    else:
        print "[*] Checked successfully!"
        with open('allcheck.txt', 'a') as f:
            f.write(check + '\n')

if __name__ == '__main__':
    create_db()
    while True:
        welcome()
        c = raw_input('Your choice:')
        c = int(c)
        if c == 0: #生成公私钥对
            pk, sk = keygen()
        elif c == 1: #签名
            sign(pk, sk)
        elif c == 2: #检查双花
            check_double_spending()
        elif c == 3: #退出
            exit()
        else: #输入错误
            print '[-] Wrong choice!'
