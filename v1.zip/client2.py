#!/usr/bin/env python
#-*- encoding=utf-8 -*-
#该程序由队伍“C-moon”实现，包括钱非凡、贾潇风、陈恺凡，队长为钱非凡
#该程序主要实现读取{σ,m}并进行签名验证算法
#该程序遵循 https://blog.csdn.net/qmickecs/article/details/73556098 的建议
#完成时间：2019/09/21
import hashlib
import gmpy2
import random
import time

#欢迎界面
def welcome():
    print ' --- Welcome to C-moon Bank System! --- '
    print '|          0: Get pk                   |'
    print '|          1: Verify                   |'
    print '|          2: Exit                     |'
    print ' -------------------------------------- '

#获取公钥
def getpk():
    with open('pk.txt', 'rb') as f:
        n = int(f.readline()[:-1])
        e = int(f.readline()[:-1])
    print '[+] n =', n
    print '[+] e =', e
    H = lambda m: int(hashlib.sha256(m).hexdigest(), 16) #hash函数
    pk = [n, e, H]
    return pk

#验证信息的真实性
#@pk：公钥
def verify(pk):
    with open('check.txt', 'rb') as f:
        check = f.read().split('|')
        sigma = int(check[0]) #去盲化的σ值
        m = check[1][:-1] #明文数据
    n = pk[0]
    e = pk[1]
    H = lambda m: int(hashlib.sha256(m).hexdigest(), 16) #hash函数
    H_m = H(m) % n #付款人盲变换后的数据
    #计算付款人盲变换后的数据
    res = gmpy2.powmod(sigma, e, n)
    if res == H_m: #验证成功
        print 'Right'
    else: #验证失败
        print 'Wrong'

if __name__ == '__main__':
    while True:
        welcome()
        c = raw_input('Your choice:')
        c = int(c)
        if c == 0:
            pk = getpk()
        elif c == 1:
            verify(pk)
        elif c == 2:
            exit()
        else:
            print 'Wrong'
