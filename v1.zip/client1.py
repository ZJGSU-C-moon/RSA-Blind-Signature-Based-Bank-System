#!/usr/bin/env python
#-*- encoding=utf-8 -*-
#该程序由队伍“C-moon”实现，包括钱非凡、贾潇风、陈恺凡，队长为钱非凡
#该程序主要实现对消息进行盲变换、对盲变换的信息进行去盲变换算法
#该程序遵循 https://blog.csdn.net/qmickecs/article/details/73556098 的建议
#完成时间：2019/09/21
import hashlib
import gmpy2
import random
import time
import socket

#欢迎界面
def welcome():
    print ' --- Welcome to C-moon Bank System! --- '
    print '|          0: Get pk                   |'
    print '|          1: Calculate M              |'
    print '|          2: Caculate σ               |'
    print '|          3: Exit                     |'
    print ' -------------------------------------- '

#获取公钥
def getpk():
    with open('pk.txt', 'rb') as f:
        n = int(f.readline()[:-1])
        e = int(f.readline()[:-1])
    print '[+] n =', n
    print '[+] e =', e
    H = lambda m: int(hashlib.sha256(m).hexdigest(), 16) #hash函数
    pk = [n, e, H]
    return pk

#计算M的值
#@R：付款人获取的随机数，范围在0～n之间
#@pk：RSA公钥
#@m：明文数据
def CalM(R, pk, m):
    n = pk[0]
    e = pk[1]
    H = pk[2]
    #付款人信息输入点
    H_m = H(m) % n
    R_e = gmpy2.powmod(R, e, n)
    M = R_e * H_m % n
    print '[+] M =', M
    with open('M.txt', 'wb') as f:
        f.write(str(int(M)))

#计算σ的值
#@R：付款人获取的随机数，范围在0～n之间
#@pk：RSA公钥
#@m：明文数据
def CalSigma(R, pk, m):
    with open('sigma.txt', 'rb') as f:
        sigmadot = int(f.read()) #未进行盲变换的σ值
    n = pk[0]
    R_ = gmpy2.invert(R, n)
    sigma = gmpy2.mul(sigmadot, R_) % n
    print '[+] σ =', sigma
    check = str(int(sigma)) + '|' + m
    with open('check.txt', 'wb') as f:
        f.write(str(check) + '\n')

if __name__ == '__main__':
    while True:
        welcome()
        c = raw_input('Your choice:')
        c = int(c)
        if c == 0: #获取公钥
            pk = getpk()
            n = pk[0]
            e = pk[1]
            H = pk[2]
        elif c == 1: #计算M值
            R = random.randrange(0, n) #获取随机数R
            m = raw_input('Please input your data:')
            CalM(R, pk, m)
        elif c == 2: #计算σ值
            CalSigma(R, pk, m)
        elif c == 3: #退出
            exit()
        else: #输入错误
            print '[-] Wrong choice!'
